import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { buildFreeAiHeaders, freeAiDiagnostics, getFreeAiConfig } from "./free-ai.ts";
import { COURSE_QA_PROMPT } from "./prompts/course-qa.prompt.ts";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export type AppErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "COURSE_NOT_FOUND"
  | "INVALID_INPUT"
  | "DATABASE_ERROR"
  | "AI_RESPONSE_INVALID"
  | "GENERATION_FAILED"
  | "QA_FAILED"
  | "QA_RESPONSE_INVALID"
  | "VERSION_NOT_FOUND"
  | "VERSION_SNAPSHOT_INVALID"
  | "VERSION_RESTORE_FAILED"
  | "RESTORE_BLOCKED";

export class AppError extends Error {
  code: AppErrorCode;
  status: number;
  details: Record<string, unknown>;

  constructor(code: AppErrorCode, message: string, status = 400, details: Record<string, unknown> = {}) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

export function errorResponse(error: unknown) {
  if (error instanceof AppError) {
    return jsonResponse({ error: { code: error.code, message: error.message, details: error.details ?? {} } }, error.status);
  }
  console.error(error);
  return jsonResponse({ error: { code: "DATABASE_ERROR", message: "Внутренняя ошибка сервера", details: {} } }, 500);
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function clean(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value).trim();
  return "";
}

export async function readJson(req: Request) {
  if (req.method === "OPTIONS") return null;
  if (req.method !== "POST") throw new AppError("INVALID_INPUT", "Метод не поддерживается", 405);
  const raw = await req.text();
  if (!raw.trim()) throw new AppError("INVALID_INPUT", "Пустое тело запроса", 400);
  try {
    return JSON.parse(raw);
  } catch {
    throw new AppError("INVALID_INPUT", "Некорректный JSON в теле запроса", 400);
  }
}

export function createAdminClient() {
  const url = Deno.env.get("SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) throw new AppError("DATABASE_ERROR", "Не настроены переменные Supabase", 500);
  return createClient(url, key, { auth: { persistSession: false } });
}

export function extractBearerToken(req: Request): string {
  const raw = req.headers.get("authorization") ?? req.headers.get("Authorization") ?? "";
  const firstBearer = raw
    .split(",")
    .map((part) => part.trim())
    .find((part) => /^Bearer\s+/i.test(part));

  const token = (firstBearer ?? raw).replace(/^Bearer\s+/i, "").trim();
  if (!token || token.includes(",")) {
    throw new AppError("UNAUTHORIZED", "Требуется авторизация", 401);
  }
  return token;
}

export async function getAuthUser(req: Request, supabaseAdmin: any) {
  const token = extractBearerToken(req);
  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data?.user) throw new AppError("UNAUTHORIZED", "Сессия недействительна", 401);
  return data.user;
}

export function asUuid(value: unknown, field: string) {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new AppError("INVALID_INPUT", `Некорректный ${field}`, 400);
  }
  return value;
}

export async function loadOwnedCourse(supabaseAdmin: any, courseId: string, userId: string) {
  const { data: course, error } = await supabaseAdmin.from("courses").select("*").eq("id", courseId).maybeSingle();
  if (error) throw new AppError("DATABASE_ERROR", "Не удалось загрузить курс", 500, { message: error.message });
  if (!course) throw new AppError("COURSE_NOT_FOUND", "Курс не найден", 404);
  if (course.author_id !== userId) throw new AppError("FORBIDDEN", "Нет доступа к курсу", 403);
  return course;
}

export async function writeAuditLog(input: {
  supabaseAdmin: any;
  userId?: string | null;
  courseId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  metadata?: Record<string, unknown>;
}) {
  try {
    const payload = sanitizeMetadata(input.metadata ?? {});
    await input.supabaseAdmin.from("audit_logs").insert({
      actor_user_id: input.userId ?? null,
      course_id: input.courseId ?? null,
      entity_type: input.entityType,
      entity_id: input.entityId ?? null,
      action: input.action,
      payload,
    });
  } catch (error) {
    console.warn("audit_log_insert_failed", error);
  }
}

function sanitizeMetadata(value: Record<string, unknown>) {
  const blocked = new Set(["OPENAI_API_KEY", "SUPABASE_SERVICE_ROLE_KEY", "JWT", "raw_text", "snapshot_data", "stack"]);
  const out: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(value)) {
    if (blocked.has(key)) continue;
    if (typeof val === "string" && val.length > 4000) out[key] = `${val.slice(0, 4000)}…`;
    else out[key] = val;
  }
  return out;
}

export async function loadCourseSnapshot(supabaseAdmin: any, courseId: string) {
  const { data: course, error: courseError } = await supabaseAdmin.from("courses").select("*").eq("id", courseId).maybeSingle();
  if (courseError) throw new AppError("DATABASE_ERROR", "Не удалось загрузить курс", 500, { message: courseError.message });
  if (!course) throw new AppError("COURSE_NOT_FOUND", "Курс не найден", 404);

  const { data: modules } = await supabaseAdmin.from("modules").select("*").eq("course_id", courseId).order("position", { ascending: true });
  const moduleIds = (modules ?? []).map((m: any) => m.id);

  const { data: lessons } = moduleIds.length
    ? await supabaseAdmin.from("lessons").select("*").in("module_id", moduleIds).order("position", { ascending: true })
    : { data: [] };
  const lessonIds = (lessons ?? []).map((l: any) => l.id);

  const { data: lessonContents } = lessonIds.length
    ? await supabaseAdmin.from("lesson_contents").select("*").in("lesson_id", lessonIds)
    : { data: [] };

  const { data: sources } = await supabaseAdmin.from("sources").select("*").eq("course_id", courseId);

  const { data: courseQuizzes } = await supabaseAdmin.from("quizzes").select("*").eq("course_id", courseId);
  const { data: lessonQuizzes } = lessonIds.length
    ? await supabaseAdmin.from("quizzes").select("*").in("lesson_id", lessonIds)
    : { data: [] };
  const quizMap = new Map<string, any>();
  for (const q of [...(courseQuizzes ?? []), ...(lessonQuizzes ?? [])]) quizMap.set(q.id, q);
  const quizzes = [...quizMap.values()];
  const quizIds = quizzes.map((q: any) => q.id);

  const { data: questions } = quizIds.length
    ? await supabaseAdmin.from("questions").select("*").in("quiz_id", quizIds).order("position", { ascending: true })
    : { data: [] };
  const questionIds = (questions ?? []).map((q: any) => q.id);

  const { data: answerOptions } = questionIds.length
    ? await supabaseAdmin.from("answer_options").select("*").in("question_id", questionIds).order("position", { ascending: true })
    : { data: [] };

  const { data: qaReports } = await supabaseAdmin.from("qa_reports").select("*").eq("course_id", courseId).order("created_at", { ascending: false }).limit(10);

  return {
    schema_version: 1,
    captured_at: new Date().toISOString(),
    course,
    modules: modules ?? [],
    lessons: lessons ?? [],
    lesson_contents: lessonContents ?? [],
    sources: sources ?? [],
    quizzes,
    questions: questions ?? [],
    answer_options: answerOptions ?? [],
    qa_reports: qaReports ?? [],
  };
}

export async function createCourseVersion(input: {
  supabaseAdmin: any;
  courseId: string;
  userId: string;
  changeType: string;
  changeDescription: string;
  qaScore?: number | null;
  auditMetadata?: Record<string, unknown>;
}) {
  const snapshot = await loadCourseSnapshot(input.supabaseAdmin, input.courseId);
  const { data: maxRows, error: maxError } = await input.supabaseAdmin
    .from("course_versions")
    .select("version_number")
    .eq("course_id", input.courseId)
    .order("version_number", { ascending: false })
    .limit(1);
  if (maxError) throw new AppError("DATABASE_ERROR", "Не удалось определить номер версии", 500, { message: maxError.message });
  const nextNumber = ((maxRows?.[0]?.version_number as number | undefined) ?? 0) + 1;
  const { data: version, error } = await input.supabaseAdmin
    .from("course_versions")
    .insert({
      course_id: input.courseId,
      version_number: nextNumber,
      change_type: input.changeType,
      change_description: input.changeDescription,
      qa_score: input.qaScore ?? null,
      created_by: input.userId,
      snapshot_data: snapshot,
    })
    .select("*")
    .single();
  if (error) throw new AppError("DATABASE_ERROR", "Не удалось создать версию курса", 500, { message: error.message });
  await input.supabaseAdmin.from("courses").update({ current_version_id: version.id }).eq("id", input.courseId);
  await writeAuditLog({
    supabaseAdmin: input.supabaseAdmin,
    userId: input.userId,
    courseId: input.courseId,
    action: "course_version_created",
    entityType: "course_version",
    entityId: version.id,
    metadata: { change_type: input.changeType, version_number: nextNumber, ...(input.auditMetadata ?? {}) },
  });
  return version;
}

export function clampScore(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.round(n)));
}

type QaScope = "plan" | "current" | "course";

const LESSON_CONTENT_FIELDS = ["theory_text", "examples_text", "practice_text", "checklist_text"];

function hasMeaningfulLessonContent(row: any) {
  return LESSON_CONTENT_FIELDS.some((field) => clean(row?.[field]).length > 0);
}

export function buildQaContext(snapshot: any, requestedScope?: QaScope) {
  const lessons = snapshot.lessons ?? [];
  const contents = snapshot.lesson_contents ?? [];
  const sources = snapshot.sources ?? [];
  const lessonIds = new Set(lessons.map((lesson: any) => lesson.id));
  const contentLessonIds = new Set(
    contents
      .filter((content: any) => lessonIds.has(content.lesson_id) && hasMeaningfulLessonContent(content))
      .map((content: any) => content.lesson_id),
  );
  const totalLessons = lessons.length;
  const evaluatedLessons = contentLessonIds.size;
  const missingContentLessons = Math.max(0, totalLessons - evaluatedLessons);
  const sourceAlignmentEnabled = sources.length > 0;
  const onlySourceMode = sourceAlignmentEnabled && sources.some((source: any) => Boolean(source.only_source_mode));
  const courseStatus = clean(snapshot.course?.status).toLowerCase();

  let scope: QaScope;
  if (requestedScope === "plan") {
    scope = "plan";
  } else if (requestedScope === "current") {
    scope = evaluatedLessons > 0 ? "current" : "plan";
  } else if (requestedScope === "course" && courseStatus === "ready" && totalLessons > 0 && missingContentLessons === 0) {
    scope = "course";
  } else if (evaluatedLessons > 0 && missingContentLessons > 0) {
    scope = "current";
  } else if (evaluatedLessons > 0 && missingContentLessons === 0) {
    scope = "course";
  } else {
    scope = "plan";
  }

  const message = scope === "plan"
    ? "Проверяется только структура курса: модули, уроки, цели, описания и результаты обучения. Отсутствие содержимого уроков и квизов не снижает балл."
    : scope === "current"
      ? `Проверены ${evaluatedLessons} урока из ${totalLessons}. Остальные уроки добавлены в рекомендации и не снижают QA-балл.`
      : "Проверяется полный доступный курс: структура, содержимое уроков, квизы и согласованность материалов.";

  return {
    mode: scope,
    total_lessons_count: totalLessons,
    evaluated_lessons_count: scope === "plan" ? 0 : evaluatedLessons,
    missing_content_lessons_count: scope === "plan" ? totalLessons : missingContentLessons,
    source_alignment_enabled: sourceAlignmentEnabled,
    only_source_mode: onlySourceMode,
    message,
  };
}

function averageScores(scores: Array<number | null | undefined>) {
  const normalized = scores.filter((score): score is number => typeof score === "number" && Number.isFinite(score));
  if (!normalized.length) return 0;
  return Math.round(normalized.reduce((sum, score) => sum + score, 0) / normalized.length);
}

function looksLikeFutureContentIssue(item: any) {
  const record = asRecord(item) ?? {};
  const text = [record.type, record.title, record.description, record.reason, record.message, record.recommendation]
    .map((value) => clean(value).toLowerCase())
    .join(" ");
  return [
    "нет содержимого",
    "не имеет lesson_contents",
    "lesson_contents",
    "отсутствует содержимое",
    "нет квиз",
    "нет quiz",
    "отсутствует квиз",
    "quizzes",
    "quiz",
  ].some((marker) => text.includes(marker));
}

function hasRecommendation(recommendations: any[], text: string) {
  const normalizedTarget = text.trim().toLowerCase();
  return recommendations.some((item) => {
    if (typeof item === "string") return item.trim().toLowerCase() === normalizedTarget;
    const record = asRecord(item);
    return [record?.title, record?.description, record?.recommendation, record?.text]
      .map((value) => clean(value).toLowerCase())
      .some((value) => value === normalizedTarget || value.includes(normalizedTarget));
  });
}

function totalFromAvailableScores(context: ReturnType<typeof buildQaContext>, scores: {
  structureScore: number;
  coherenceScore: number;
  levelScore: number;
  sourceScore: number | null;
}) {
  const scoreParts = context.source_alignment_enabled
    ? [scores.structureScore, scores.coherenceScore, scores.levelScore, scores.sourceScore]
    : [scores.structureScore, scores.coherenceScore, scores.levelScore];
  return averageScores(scoreParts);
}

function withQaContext(result: any, snapshot: any, qaScope: QaScope) {
  const context = buildQaContext(snapshot, qaScope);
  let issues = Array.isArray(result.issues) ? result.issues : [];
  let recommendations = Array.isArray(result.recommendations) ? result.recommendations : [];

  if (context.mode !== "course") {
    issues = issues.filter((item: any) => !looksLikeFutureContentIssue(item));
  }

  if (context.missing_content_lessons_count > 0) {
    const text = context.mode === "current"
      ? `Сгенерировать недостающие ${context.missing_content_lessons_count} уроков`
      : `Сгенерировать содержимое для ${context.total_lessons_count} уроков`;
    if (!hasRecommendation(recommendations, text)) recommendations = [...recommendations, text];
  }

  const structureScore = clampScore(result.structure_score);
  const coherenceScore = clampScore(result.coherence_score);
  const levelScore = clampScore(result.level_match_score);
  const sourceScore = context.source_alignment_enabled ? clampScore(result.source_alignment_score) : null;
  const totalScore = totalFromAvailableScores(context, { structureScore, coherenceScore, levelScore, sourceScore });
  const resultSourceAlignment = asRecord(result.source_alignment);

  return {
    ...result,
    structure_score: structureScore,
    coherence_score: coherenceScore,
    level_match_score: levelScore,
    source_alignment_score: sourceScore,
    total_score: totalScore,
    summary: clean(result.summary) || (context.mode === "current" ? `Проверены ${context.evaluated_lessons_count} урока из ${context.total_lessons_count}` : context.message),
    issues,
    recommendations,
    suspicious_facts: Array.isArray(result.suspicious_facts) ? result.suspicious_facts : [],
    source_alignment: context.source_alignment_enabled
      ? {
          enabled: true,
          only_source_mode: context.only_source_mode,
          summary: clean(resultSourceAlignment?.summary),
          unsupported_claims: Array.isArray(resultSourceAlignment?.unsupported_claims) ? resultSourceAlignment?.unsupported_claims : [],
        }
      : {
          enabled: false,
          only_source_mode: false,
          summary: "",
          unsupported_claims: [],
        },
    qa_scope: context,
  };
}

export function buildRuleBasedQa(snapshot: any, qaScope: QaScope = "course") {
  const allModules = snapshot.modules ?? [];
  const allLessons = snapshot.lessons ?? [];
  const contents = snapshot.lesson_contents ?? [];
  const allQuizzes = snapshot.quizzes ?? [];
  const issues: any[] = [];
  const recommendations: any[] = [];
  const context = buildQaContext(snapshot, qaScope);
  const isPlanScope = context.mode === "plan";
  const evaluatedLessonIds = getEvaluatedLessonIds(snapshot);
  const lessons = context.mode === "current"
    ? allLessons.filter((lesson: any) => evaluatedLessonIds.has(lesson.id))
    : allLessons;
  const scopedLessonIds = new Set(lessons.map((lesson: any) => lesson.id));
  const scopedModuleIds = new Set(lessons.map((lesson: any) => lesson.module_id));
  const modules = context.mode === "current"
    ? allModules.filter((module: any) => scopedModuleIds.has(module.id))
    : allModules;
  const quizzes = context.mode === "current"
    ? allQuizzes.filter((quiz: any) => !quiz.lesson_id || scopedLessonIds.has(quiz.lesson_id))
    : allQuizzes;

  if (!modules.length) issues.push(issue("critical", "structure", "Нет модулей", "Курс не содержит модулей.", "course", snapshot.course?.id, "Сгенерируйте или добавьте модули."));
  if (!lessons.length) issues.push(issue("critical", "structure", "Нет уроков", "Курс не содержит доступных уроков для проверки.", "course", snapshot.course?.id, "Сгенерируйте содержимое хотя бы для одного урока."));

  for (const lesson of lessons) {
    if (!String(lesson.objective ?? "").trim()) issues.push(issue("medium", "completeness", "У урока нет цели", `Урок «${lesson.title ?? "Без названия"}» не содержит objective.`, "lesson", lesson.id, "Добавьте цель урока."));
    if (!String(lesson.summary ?? "").trim()) issues.push(issue("medium", "completeness", "У урока нет описания", `Урок «${lesson.title ?? "Без названия"}» не содержит summary.`, "lesson", lesson.id, "Добавьте краткое описание."));
    if (!String(lesson.learning_outcome ?? "").trim()) issues.push(issue("medium", "completeness", "У урока нет результата обучения", `Урок «${lesson.title ?? "Без названия"}» не содержит learning_outcome.`, "lesson", lesson.id, "Добавьте ожидаемый результат."));

    const lc = contents.find((content: any) => content.lesson_id === lesson.id);
    if (lc && hasMeaningfulLessonContent(lc)) {
      const emptyFields = LESSON_CONTENT_FIELDS.filter((field) => !String(lc[field] ?? "").trim());
      if (emptyFields.length && context.mode === "course") {
        recommendations.push(rec("medium", "Дополнить блоки урока", `В уроке «${lesson.title ?? "Без названия"}» пустые блоки: ${emptyFields.join(", ")}.`, "lesson_content"));
      }
    }
  }

  if (!isPlanScope && !quizzes.length) {
    recommendations.push(rec("medium", "Добавить квизы", "В доступной части курса пока нет квизов. Добавьте квиз к ключевым урокам или итоговый квиз, когда будете готовы к полной проверке.", "quizzes"));
  }

  const completenessPenalty = Math.min(35, issues.filter((x) => x.severity === "high" || x.severity === "critical").length * 12 + issues.filter((x) => x.severity === "medium").length * 4);
  const structureScore = modules.length && lessons.length ? 88 : 30;
  const coherenceScore = context.mode === "plan" ? 86 : 88;
  const levelScore = 82;
  const sourceScore = context.source_alignment_enabled ? 84 : null;
  const baseTotal = totalFromAvailableScores(context, { structureScore, coherenceScore, levelScore, sourceScore });

  return withQaContext({
    structure_score: clampScore(structureScore - completenessPenalty / 2),
    coherence_score: clampScore(coherenceScore - completenessPenalty / 3),
    level_match_score: clampScore(levelScore),
    source_alignment_score: sourceScore,
    total_score: clampScore(baseTotal - completenessPenalty),
    summary: context.message,
    issues,
    recommendations,
    suspicious_facts: [],
    source_alignment: null,
    fallback: true,
  }, snapshot, context.mode);
}

function issue(severity: string, type: string, title: string, description: string, entity_type: string, entity_id: string | null, recommendation: string) {
  return { severity, type, title, description, entity_type, entity_id: entity_id ?? null, recommendation };
}
function rec(priority: string, title: string, description: string, target: string) {
  return { priority, title, description, target };
}

export function stripMarkdownJson(text: string) {
  return text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
}

function aiEnv() {
  const config = getFreeAiConfig();
  return { apiKey: config.apiKey, baseUrl: config.baseUrl, model: config.model, provider: config.provider, config };
}

function extractTextContent(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (Array.isArray(value)) {
    return value.map((part) => {
      if (typeof part === "string") return part;
      const record = asRecord(part);
      return clean(record?.text) || clean(record?.content) || clean(asRecord(record?.text)?.value);
    }).filter(Boolean).join("\n").trim();
  }
  return clean(value);
}

function fillQaPrompt(template: string, values: Record<string, string>) {
  let out = template;
  for (const [key, value] of Object.entries(values)) out = out.replaceAll(`{{${key}}}`, value);
  return out;
}

export async function runAiQa(snapshot: any, qaScope: QaScope = "course") {
  const { apiKey, baseUrl, model, provider, config } = aiEnv();
  if (!apiKey) return null;
  const context = buildQaContext(snapshot, qaScope);
  const compactSnapshot = compactForQa(snapshot, context);
  const sourceRule = context.source_alignment_enabled
    ? "Курс содержит пользовательские sources: оцени source_alignment_score числом 0..100, выставь source_alignment.enabled=true и укажи неподтверждённые тезисы."
    : "Курс не содержит sources: source_alignment_score должен быть null, source_alignment.enabled=false, source_alignment.only_source_mode=false, source_alignment.summary=\"\", unsupported_claims=[]. Не включай источники в total_score.";
  const scopeRule = context.mode === "plan"
    ? "Проверяй только план: модули, уроки, цели, описания, тайминг и результаты обучения. Отсутствие lesson_contents, квизов и практики не является ошибкой и не снижает балл."
    : context.mode === "current"
      ? `Проверяй только доступные уроки с lesson_contents: ${context.evaluated_lessons_count} из ${context.total_lessons_count}. Уроки без lesson_contents не являются ошибкой и не снижают балл; добавь рекомендацию \"Сгенерировать недостающие ${context.missing_content_lessons_count} уроков\".`
      : "Проверяй полный доступный курс: структуру, содержимое всех уроков, квизы, задания и согласованность материалов.";
  const userPrompt = fillQaPrompt(COURSE_QA_PROMPT, {
    qa_mode: context.mode,
    scope_rule: scopeRule,
    source_rule: sourceRule,
    qa_context: JSON.stringify(context),
    course_data: JSON.stringify(compactSnapshot),
  });
  const body: any = {
    model,
    messages: [
      { role: "system", content: "Ты QA-эксперт образовательных курсов. Верни только валидный JSON без markdown. Все обязательные числовые оценки должны быть числами 0..100; source_alignment_score может быть null только если sources отсутствуют." },
      { role: "user", content: userPrompt },
    ],
    temperature: 0.2,
  };
  const responseFormatSetting = Deno.env.get("AI_USE_RESPONSE_FORMAT")?.trim().toLowerCase();
  const useResponseFormatByDefault = responseFormatSetting === "true" || (!responseFormatSetting && provider !== "openrouter");

  async function requestQa(useResponseFormat: boolean) {
    const requestBody = { ...body };
    if (useResponseFormat) requestBody.response_format = { type: "json_object" };
    const headers = buildFreeAiHeaders(config);
    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify(requestBody),
    });
    const rawResponse = await response.text();
    let json: any = null;
    try { json = rawResponse ? JSON.parse(rawResponse) : null; } catch { json = null; }
    if (!response.ok) throw new AppError("GENERATION_FAILED", "AI API вернул ошибку", 502, { status: response.status, message: clean(asRecord(asRecord(json)?.error)?.message) || rawResponse.slice(0, 1000), used_response_format: useResponseFormat, ...freeAiDiagnostics(config) });
    const firstChoice = Array.isArray(json?.choices) ? json.choices[0] : null;
    const message = asRecord(asRecord(firstChoice)?.message);
    const parsedObject = message?.parsed;
    const content = extractTextContent(message?.content) || extractTextContent(asRecord(firstChoice)?.text);
    if (!content && !(parsedObject && typeof parsedObject === "object")) return null;
    try {
      const parsed = parsedObject && typeof parsedObject === "object" ? parsedObject as any : JSON.parse(stripMarkdownJson(content));
      if (!Array.isArray(parsed.issues) || !Array.isArray(parsed.recommendations)) return null;
      return {
        ...withQaContext(parsed, snapshot, context.mode),
        fallback: false,
      };
    } catch {
      return null;
    }
  }

  if (!useResponseFormatByDefault) return await requestQa(false);
  try {
    return await requestQa(true);
  } catch (error) {
    const detailsText = JSON.stringify(error instanceof AppError ? error.details : {}).toLowerCase();
    if (!detailsText.includes("response_format") && !detailsText.includes("json_object") && !detailsText.includes("structured") && !detailsText.includes("unsupported")) throw error;
    console.warn("AI response_format is not supported by provider/model, retrying without it");
    return await requestQa(false);
  }
}

function getEvaluatedLessonIds(snapshot: any) {
  const lessons = snapshot.lessons ?? [];
  const lessonIds = new Set(lessons.map((lesson: any) => lesson.id));
  return new Set(
    (snapshot.lesson_contents ?? [])
      .filter((content: any) => lessonIds.has(content.lesson_id) && hasMeaningfulLessonContent(content))
      .map((content: any) => content.lesson_id),
  );
}

function compactForQa(snapshot: any, context = buildQaContext(snapshot, "course")) {
  const maxSourceChars = Number(Deno.env.get("QA_MAX_SOURCE_CHARS") ?? 12000);
  const evaluatedLessonIds = getEvaluatedLessonIds(snapshot);
  const allLessons = snapshot.lessons ?? [];
  const selectedLessons = context.mode === "plan"
    ? allLessons
    : allLessons.filter((lesson: any) => evaluatedLessonIds.has(lesson.id));
  const selectedLessonIds = new Set(selectedLessons.map((lesson: any) => lesson.id));
  const selectedModuleIds = new Set(selectedLessons.map((lesson: any) => lesson.module_id));
  const modules = context.mode === "plan"
    ? snapshot.modules
    : (snapshot.modules ?? []).filter((module: any) => selectedModuleIds.has(module.id));
  const lessonContents = context.mode === "plan"
    ? []
    : (snapshot.lesson_contents ?? []).filter((content: any) => selectedLessonIds.has(content.lesson_id) && hasMeaningfulLessonContent(content));
  const quizzes = context.mode === "plan"
    ? []
    : (snapshot.quizzes ?? []).filter((quiz: any) => !quiz.lesson_id || selectedLessonIds.has(quiz.lesson_id));
  const quizIds = new Set(quizzes.map((quiz: any) => quiz.id));
  const questions = (snapshot.questions ?? []).filter((question: any) => quizIds.has(question.quiz_id));
  const questionIds = new Set(questions.map((question: any) => question.id));

  return {
    qa_scope: context,
    course: snapshot.course,
    modules,
    lessons: selectedLessons,
    lesson_contents: lessonContents.map((c: any) => ({
      ...c,
      theory_text: truncate(c.theory_text, 1500),
      examples_text: truncate(c.examples_text, 800),
      practice_text: truncate(c.practice_text, 800),
      checklist_text: truncate(c.checklist_text, 800),
    })),
    missing_lessons_note: context.missing_content_lessons_count > 0
      ? `В курсе есть ${context.missing_content_lessons_count} уроков без lesson_contents. Они исключены из оценки и должны попасть только в recommendations.`
      : "",
    sources: (snapshot.sources ?? []).map((s: any) => ({ ...s, raw_text: truncate(s.raw_text, maxSourceChars) })),
    quizzes,
    questions,
    answer_options: (snapshot.answer_options ?? [])
      .filter((option: any) => questionIds.has(option.question_id))
      .map((o: any) => ({ ...o, is_correct: undefined })),
  };
}
function truncate(value: unknown, max = 1000) {
  const text = String(value ?? "");
  return text.length > max ? `${text.slice(0, max)}…` : text;
}
