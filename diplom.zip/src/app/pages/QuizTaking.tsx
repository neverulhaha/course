export { default } from "./QuizPage";
